import{u as r}from"./index-B4C7dQAl.js";const s={__name:"index",setup(e){return r().push("/login"),(u,o)=>null}};export{s as default};
